import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Percent, Gift, Sparkles } from "lucide-react"

export default function OffersPage() {
  const offers = [
    {
      title: "Breakfast Combo",
      description: "Get Idli + Chai for just ₹50",
      discount: "20% OFF",
      icon: Sparkles,
      color: "from-primary to-secondary",
    },
    {
      title: "Student Special",
      description: "Show your ID and get 15% off on all orders",
      discount: "15% OFF",
      icon: Gift,
      color: "from-destructive to-primary",
    },
    {
      title: "Weekend Deal",
      description: "Free Lassi with any Thali order on weekends",
      discount: "FREE ITEM",
      icon: Percent,
      color: "from-accent to-primary",
    },
  ]

  return (
    <div className="min-h-screen pattern-bg">
      <Navigation />

      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">Special Offers</h1>
          <p className="text-xl text-muted-foreground">Save more on your favorite canteen food</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {offers.map((offer, index) => {
            const Icon = offer.icon
            return (
              <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow">
                <div className={`h-32 bg-gradient-to-br ${offer.color} flex items-center justify-center`}>
                  <Icon className="w-16 h-16 text-white" />
                </div>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-2xl">{offer.title}</CardTitle>
                    <Badge className="bg-destructive">{offer.discount}</Badge>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{offer.description}</p>
                </CardHeader>
                <CardContent>
                  <Button className="w-full bg-primary hover:bg-primary/90">Claim Offer</Button>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      <Footer />
    </div>
  )
}
