import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus } from "lucide-react"

const todaysPick = [
  { id: 101, name: "Paneer Paratha", price: 50, image: "/images/paneer-paratha.jpg", veg: true, special: true },
  { id: 102, name: "Aloo Paratha", price: 40, image: "/images/aloo-paratha.jpg", veg: true, special: true },
  {
    id: 103,
    name: "Mix Veg Paratha",
    price: 45,
    image: "/images/mix-veg-paratha.jpg",
    veg: true,
    special: true,
  },
  { id: 104, name: "Samosa", price: 20, image: "/images/samosa.jpg", veg: true, special: true },
  { id: 105, name: "Kachori", price: 25, image: "/images/kachori.jpg", veg: true, special: true },
  { id: 106, name: "Dabeli", price: 30, image: "/images/dabeli.jpg", veg: true, special: true },
  { id: 107, name: "Vada Pav", price: 25, image: "/images/vada-pav.jpg", veg: true, special: true },
  { id: 108, name: "Veg Pattice", price: 30, image: "/images/veg-pattice.jpg", veg: true, special: true },
  { id: 109, name: "Maggi", price: 35, image: "/images/maggi.jpg", veg: true, special: true },
  {
    id: 110,
    name: "Grilled Sandwich",
    price: 40,
    image: "/images/grilled-sandwich.jpg",
    veg: true,
    special: true,
  },
]

const menuItems = {
  breakfast: [
    { id: 1, name: "Idli Sambar", price: 40, image: "/images/idli-sambar.jpg", veg: true, popular: true },
    {
      id: 2,
      name: "Masala Dosa",
      price: 60,
      image: "/images/masala-dosa.jpg",
      veg: true,
      popular: true,
    },
    { id: 3, name: "Poha", price: 30, image: "/images/poha.jpg", veg: true },
    { id: 4, name: "Upma", price: 35, image: "/images/upma.jpg", veg: true },
  ],
  lunch: [
    {
      id: 5,
      name: "Thali",
      price: 120,
      image: "/images/thali.jpg",
      veg: true,
      popular: true,
    },
    {
      id: 6,
      name: "Chole Bhature",
      price: 80,
      image: "/images/chole-bhature.jpg",
      veg: true,
      popular: true,
    },
    { id: 7, name: "Paneer Butter Masala", price: 100, image: "/images/paneer-butter-masala.jpg", veg: true },
    { id: 8, name: "Dal Tadka", price: 70, image: "/images/dal-tadka.jpg", veg: true },
  ],
  snacks: [
    { id: 9, name: "Samosa", price: 20, image: "/images/samosa.jpg", veg: true, popular: true },
    { id: 10, name: "Vada Pav", price: 25, image: "/images/vada-pav.jpg", veg: true, popular: true },
    { id: 11, name: "Pav Bhaji", price: 60, image: "/images/pav-bhaji.jpg", veg: true },
    { id: 12, name: "Pakora", price: 30, image: "/images/pakora.jpg", veg: true },
  ],
  beverages: [
    { id: 13, name: "Masala Chai", price: 15, image: "/images/masala-chai.jpg", veg: true, popular: true },
    { id: 14, name: "Filter Coffee", price: 20, image: "/images/filter-coffee.jpg", veg: true },
    { id: 15, name: "Lassi", price: 30, image: "/images/lassi.jpg", veg: true },
    { id: 16, name: "Buttermilk", price: 15, image: "/images/buttermilk.jpg", veg: true },
  ],
}

export default function MenuPage() {
  return (
    <div className="min-h-screen pattern-bg">
      <Navigation />

      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">Our Menu</h1>
          <p className="text-xl text-muted-foreground">Authentic Indian canteen favorites, made fresh daily</p>
        </div>

        <div className="mb-16">
          <div className="text-center mb-8">
            <Badge className="mb-3 text-lg px-4 py-2 bg-gradient-to-r from-primary to-destructive">
              Today's Special
            </Badge>
            <h2 className="text-3xl font-bold">Today's Pick</h2>
            <p className="text-muted-foreground mt-2">Handpicked favorites for you today</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {todaysPick.map((item) => (
              <Card
                key={item.id}
                className="overflow-hidden hover:shadow-xl transition-all group border-2 border-primary/20"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  {item.special && (
                    <Badge className="absolute top-3 right-3 bg-gradient-to-r from-primary to-destructive">
                      Today's Pick
                    </Badge>
                  )}
                  {item.veg && (
                    <div className="absolute top-3 left-3 w-6 h-6 border-2 border-accent bg-white rounded flex items-center justify-center">
                      <div className="w-3 h-3 rounded-full bg-accent" />
                    </div>
                  )}
                </div>
                <CardContent className="pt-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <h3 className="text-lg font-bold">{item.name}</h3>
                    <span className="text-lg font-bold text-primary">₹{item.price}</span>
                  </div>
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    <Plus className="w-4 h-4 mr-2" />
                    Add to Tray
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Tabs defaultValue="breakfast" className="w-full">
          <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-4 mb-12">
            <TabsTrigger value="breakfast">Breakfast</TabsTrigger>
            <TabsTrigger value="lunch">Lunch</TabsTrigger>
            <TabsTrigger value="snacks">Snacks</TabsTrigger>
            <TabsTrigger value="beverages">Beverages</TabsTrigger>
          </TabsList>

          {Object.entries(menuItems).map(([category, items]) => (
            <TabsContent key={category} value={category}>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {items.map((item) => (
                  <Card key={item.id} className="overflow-hidden hover:shadow-xl transition-all group">
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      {item.popular && <Badge className="absolute top-3 right-3 bg-destructive">Popular</Badge>}
                      {item.veg && (
                        <div className="absolute top-3 left-3 w-6 h-6 border-2 border-accent bg-white rounded flex items-center justify-center">
                          <div className="w-3 h-3 rounded-full bg-accent" />
                        </div>
                      )}
                    </div>
                    <CardContent className="pt-4 space-y-3">
                      <div className="flex justify-between items-start">
                        <h3 className="text-lg font-bold">{item.name}</h3>
                        <span className="text-lg font-bold text-primary">₹{item.price}</span>
                      </div>
                      <Button className="w-full bg-primary hover:bg-primary/90">
                        <Plus className="w-4 h-4 mr-2" />
                        Add to Tray
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>

      <Footer />
    </div>
  )
}
