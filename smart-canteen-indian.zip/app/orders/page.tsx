import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, CheckCircle, Package } from "lucide-react"

export default function OrdersPage() {
  const orders = [
    { id: "ORD001", items: "Masala Dosa, Chai", total: 75, status: "ready", time: "10 mins ago" },
    { id: "ORD002", items: "Samosa (2), Coffee", total: 60, status: "preparing", time: "5 mins ago" },
    { id: "ORD003", items: "Thali, Lassi", total: 150, status: "completed", time: "2 hours ago" },
  ]

  return (
    <div className="min-h-screen pattern-bg">
      <Navigation />

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl font-bold mb-8">My Orders</h1>

          <div className="space-y-4">
            {orders.map((order) => (
              <Card key={order.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">Order #{order.id}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">{order.time}</p>
                    </div>
                    <Badge
                      variant={
                        order.status === "ready" ? "default" : order.status === "preparing" ? "secondary" : "outline"
                      }
                      className={
                        order.status === "ready" ? "bg-accent" : order.status === "preparing" ? "bg-secondary" : ""
                      }
                    >
                      {order.status === "ready" && <CheckCircle className="w-3 h-3 mr-1" />}
                      {order.status === "preparing" && <Clock className="w-3 h-3 mr-1" />}
                      {order.status === "completed" && <Package className="w-3 h-3 mr-1" />}
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <p className="text-muted-foreground">{order.items}</p>
                    <p className="text-lg font-bold text-primary">₹{order.total}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
