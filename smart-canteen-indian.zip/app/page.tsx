import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { UtensilsCrossed, ShoppingBag, Clock, Calendar, History, Users, Leaf } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen pattern-bg">
      <Navigation />

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
        <div className="container mx-auto px-4 py-20 md:py-32 relative">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-balance leading-tight">
                Welcome to{" "}
                <span className="bg-gradient-to-r from-primary via-destructive to-secondary bg-clip-text text-transparent">
                  Smart Canteen
                </span>
              </h1>
              <p className="text-xl text-muted-foreground text-pretty leading-relaxed">
                Order authentic Indian canteen food online, skip the queue, and enjoy your meal without the wait. Fresh
                samosas, hot chai, crispy dosas, and more!
              </p>
              <div className="flex flex-wrap gap-4">
                <Button size="lg" asChild className="bg-primary hover:bg-primary/90 text-lg px-8">
                  <Link href="/menu">Order Now</Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="text-lg px-8 bg-transparent">
                  <Link href="/login">Login</Link>
                </Button>
              </div>
            </div>
            <div className="relative h-[400px] md:h-[500px]">
              <img
                src="/colorful-indian-thali-with-various-dishes--samosas.jpg"
                alt="Indian Canteen Food"
                className="rounded-2xl shadow-2xl object-cover w-full h-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">How It Works</h2>
          <p className="text-xl text-muted-foreground">Three simple steps to enjoy your favorite canteen food</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <Card className="border-2 hover:border-primary transition-colors">
            <CardContent className="pt-8 text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto">
                <UtensilsCrossed className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold">Browse Menu</h3>
              <p className="text-muted-foreground leading-relaxed">
                Explore our diverse menu with breakfast, lunch, snacks, and beverages. From crispy samosas to steaming
                chai!
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-primary transition-colors">
            <CardContent className="pt-8 text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-br from-destructive to-primary rounded-2xl flex items-center justify-center mx-auto">
                <ShoppingBag className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold">Place Order</h3>
              <p className="text-muted-foreground leading-relaxed">
                Add items to cart, pay online securely, and confirm your order. Quick checkout with Razorpay
                integration.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-primary transition-colors">
            <CardContent className="pt-8 text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-br from-accent to-primary rounded-2xl flex items-center justify-center mx-auto">
                <Clock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold">Skip the Queue</h3>
              <p className="text-muted-foreground leading-relaxed">
                Get real-time updates and pick up your order when it's ready. No more waiting in long canteen lines!
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Why Choose Smart Canteen */}
      <section className="bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Why Choose Smart Canteen?</h2>
            <p className="text-xl text-muted-foreground">Experience the future of canteen ordering</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6 space-y-3">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Pre-Book Orders</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Schedule your meals in advance for a specific pickup time. Perfect for busy schedules!
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6 space-y-3">
                <div className="w-12 h-12 bg-destructive/10 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-destructive" />
                </div>
                <h3 className="text-xl font-bold">Real-Time Queue</h3>
                <p className="text-muted-foreground leading-relaxed">
                  See live queue status and estimated preparation time. Know exactly when to pick up!
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6 space-y-3">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-xl font-bold">Order Tracking</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Track your order status from preparation to ready for pickup. Stay informed every step!
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6 space-y-3">
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center">
                  <ShoppingBag className="w-6 h-6 text-secondary" />
                </div>
                <h3 className="text-xl font-bold">Easy Checkout</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Quick and secure payment with Razorpay integration. Multiple payment options available!
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6 space-y-3">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <History className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Order History</h3>
                <p className="text-muted-foreground leading-relaxed">
                  View all your past orders and reorder with one click. Your favorites, always accessible!
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6 space-y-3">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                  <Leaf className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-xl font-bold">Fresh Food</h3>
                <p className="text-muted-foreground leading-relaxed">
                  All items are freshly prepared with quality ingredients. Taste the authentic canteen flavors!
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Popular Items Preview */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Popular Items</h2>
          <p className="text-xl text-muted-foreground">Student favorites from our canteen</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { name: "Samosa", price: "₹20", image: "crispy golden samosa with chutney, indian street food" },
            { name: "Masala Dosa", price: "₹60", image: "crispy masala dosa with sambar and chutney" },
            { name: "Chai", price: "₹15", image: "hot indian chai tea in traditional glass" },
            { name: "Vada Pav", price: "₹25", image: "vada pav mumbai street food with chutney" },
          ].map((item) => (
            <Card key={item.name} className="overflow-hidden hover:shadow-xl transition-shadow group">
              <div className="relative h-48 overflow-hidden">
                <img
                  src={`/.jpg?height=200&width=300&query=${item.image}`}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <CardContent className="pt-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-bold">{item.name}</h3>
                  <span className="text-lg font-bold text-primary">{item.price}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-8">
          <Button size="lg" asChild className="bg-primary hover:bg-primary/90">
            <Link href="/menu">View Full Menu</Link>
          </Button>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-primary via-destructive to-secondary py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 text-balance">Ready to Order?</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto text-pretty leading-relaxed">
            Join hundreds of students enjoying quick and convenient canteen ordering. Skip the queue today!
          </p>
          <Button size="lg" variant="secondary" asChild className="text-lg px-8">
            <Link href="/register">Sign Up Now</Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
